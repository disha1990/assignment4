﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Employee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox5.Visible = true;
            TextBox5.Text = Calendar1.SelectedDate.ToShortDateString();
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //HttpCookie Cookie = new HttpCookie("Username");
            //Cookie.Value = TextBox1.Text;
            //Cookie.Expires = DateTime.Now.AddHours(1);
            //Response.Cookies.Add(Cookie);
            Server.Transfer("ShowInfo.aspx"); 
        }
    }
}